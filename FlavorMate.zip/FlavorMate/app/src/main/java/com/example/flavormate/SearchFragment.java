package com.example.flavormate;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import androidx.fragment.app.Fragment;

public class SearchFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search, container, false);

        // Найдём заголовки категорий и контейнеры для ингредиентов
        TextView mainCategoryTitle = view.findViewById(R.id.mainCategoryTitle);
        LinearLayout mainIngredientsContainer = view.findViewById(R.id.mainIngredientsContainer);

        TextView vegetableCategoryTitle = view.findViewById(R.id.vegetableCategoryTitle);
        LinearLayout vegetableCategoryCheckBoxContainer = view.findViewById(R.id.vegetableCategoryCheckBoxContainer);

        TextView fruitCategoryTitle = view.findViewById(R.id.fruitCategoryTitle);
        LinearLayout fruitCategoryCheckBoxContainer = view.findViewById(R.id.fruitCategoryCheckBoxContainer);

        // Кнопка "Найти рецепт"
        Button searchRecipeButton = view.findViewById(R.id.searchRecipeButton);

        // Устанавливаем категорию "Главные" как раскрытую при старте
        mainIngredientsContainer.setVisibility(View.VISIBLE);

        // Клик по заголовку категории "Главные" - раскрываем/скрываем список ингредиентов
        mainCategoryTitle.setOnClickListener(v -> toggleVisibility(mainIngredientsContainer));

        // Клик по заголовку категории "Овощи" - раскрываем/скрываем список ингредиентов
        vegetableCategoryTitle.setOnClickListener(v -> toggleVisibility(vegetableCategoryCheckBoxContainer));

        // Клик по заголовку категории "Фрукты" - раскрываем/скрываем список ингредиентов
        fruitCategoryTitle.setOnClickListener(v -> toggleVisibility(fruitCategoryCheckBoxContainer));

        // Устанавливаем обработчик для кнопки "Найти рецепт"
        searchRecipeButton.setOnClickListener(v -> onSearchRecipeClicked());

        return view;
    }

    private void toggleVisibility(final View view) {
        // Получаем текущую высоту только один раз
        final int initialHeight = view.getMeasuredHeight();

        // Если элемент скрыт, делаем его видимым с анимацией
        if (view.getVisibility() == View.GONE) {
            view.setVisibility(View.VISIBLE);

            // Измеряем высоту элемента, чтобы узнать, насколько его нужно развернуть
            view.getLayoutParams().height = 1;
            view.measure(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            final int targetHeight = view.getMeasuredHeight();

            // Анимация раскрытия
            Animation expandAnimation = new Animation() {
                @Override
                protected void applyTransformation(float interpolatedTime, Transformation t) {
                    view.getLayoutParams().height = interpolatedTime == 1
                            ? targetHeight
                            : (int) (initialHeight + (targetHeight - initialHeight) * interpolatedTime);
                    view.requestLayout();
                }

                @Override
                public boolean willChangeBounds() {
                    return true;
                }
            };

            expandAnimation.setDuration(300); // Время анимации
            view.startAnimation(expandAnimation);
        } else {
            // Если элемент видим, скрываем его с анимацией
            final int collapseHeight = view.getMeasuredHeight(); // Изменил имя переменной на collapseHeight

            Animation collapseAnimation = new Animation() {
                @Override
                protected void applyTransformation(float interpolatedTime, Transformation t) {
                    if (interpolatedTime == 1) {
                        view.setVisibility(View.GONE);
                    } else {
                        view.getLayoutParams().height = (int) (collapseHeight - collapseHeight * interpolatedTime);
                        view.requestLayout();
                    }
                }

                @Override
                public boolean willChangeBounds() {
                    return true;
                }
            };

            collapseAnimation.setDuration(300); // Время анимации
            view.startAnimation(collapseAnimation);
        }
    }

    // Обработчик для кнопки "Найти рецепт"
    private void onSearchRecipeClicked() {
        // Здесь будет логика, которая выполнится при нажатии на кнопку
        // Например, можно запустить новое активити или выполнить поиск рецептов
        // Для примера:
        // Toast.makeText(getContext(), "Поиск рецептов...", Toast.LENGTH_SHORT).show();

        // Пример перехода на другую активность
        // Intent intent = new Intent(getActivity(), SearchResultsActivity.class);
        // startActivity(intent);
    }
}

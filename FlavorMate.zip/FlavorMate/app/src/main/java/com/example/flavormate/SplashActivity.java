package com.example.flavormate;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        TextView loadingText = findViewById(R.id.loadingText);
        String baseText = "Загрузка";
        StringBuilder dots = new StringBuilder();

        Handler handler = new Handler();
        Runnable runnable = new Runnable() {
            int count = 0;

            @Override
            public void run() {
                if (count < 3) {
                    dots.append(".");
                    count++;
                } else {
                    dots.setLength(0);
                    count = 0;
                }
                loadingText.setText(baseText + dots.toString());
                handler.postDelayed(this, 500);
            }
        };

        handler.post(runnable);

        new Handler().postDelayed(() -> {
            Intent intent = new Intent(SplashActivity.this, LoginActivity.class); // Переход на LoginActivity
            startActivity(intent);
            finish();
        }, 3000);
    }
}

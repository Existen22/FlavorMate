package com.example.flavormate;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button loginButton = findViewById(R.id.login_button);
        loginButton.setOnClickListener(v -> {
            EditText emailField = findViewById(R.id.email_field);
            EditText passwordField = findViewById(R.id.password_field);

            String email = emailField.getText().toString();
            String password = passwordField.getText().toString();

            if (email.isEmpty() || password.isEmpty()) {
                TextView errorMessage = findViewById(R.id.error_message);
                errorMessage.setText("Пожалуйста, заполните все поля");
            } else {
                SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
                String savedEmail = prefs.getString("email", "");
                String savedPassword = prefs.getString("password", "");

                if (email.equals(savedEmail) && password.equals(savedPassword)) {
                    Toast.makeText(getApplicationContext(), "Успешная авторизация!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class); // Переход на MainActivity
                    startActivity(intent);
                    finish();
                } else {
                    TextView errorMessage = findViewById(R.id.error_message);
                    errorMessage.setText("Неверный email или пароль");
                }
            }
        });

        TextView registerLink = findViewById(R.id.register_link);
        registerLink.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        TextView guestModeLink = findViewById(R.id.guest_mode_link);
        guestModeLink.setOnClickListener(v -> {
            // Переход в профиль для гостя
            Intent intent = new Intent(LoginActivity.this, MainActivity.class); // Переход на MainActivity
            intent.putExtra("isGuest", true);  // Мы передаем флаг, что это гость
            startActivity(intent);
            finish();
        });
    }
}

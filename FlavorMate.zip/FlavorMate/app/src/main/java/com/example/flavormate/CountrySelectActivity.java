package com.example.flavormate;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import androidx.appcompat.app.AppCompatActivity;

public class CountrySelectActivity extends AppCompatActivity {

    private ImageButton backButtonCountry;
    private ListView countryListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country_select);

        backButtonCountry = findViewById(R.id.backButtonCountry);
        countryListView = findViewById(R.id.countryListView);

        String[] countries = {"США", "Россия", "Канада", "Германия", "Франция"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, countries);
        countryListView.setAdapter(adapter);

        backButtonCountry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}

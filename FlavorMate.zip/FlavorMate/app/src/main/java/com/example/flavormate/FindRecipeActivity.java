package com.example.flavormate;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FindRecipeActivity extends AppCompatActivity {

    private LinearLayout essentialLayout, milkAndEggsLayout, cheesesLayout, vegetablesLayout, fruitsLayout, meatsLayout, grainsLayout, spicesLayout;
    private Map<String, List<CheckBox>> checkBoxMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_recipe);

        Button backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        essentialLayout = findViewById(R.id.essentialLayout);
        milkAndEggsLayout = findViewById(R.id.milkAndEggsLayout);
        cheesesLayout = findViewById(R.id.cheesesLayout);
        vegetablesLayout = findViewById(R.id.vegetablesLayout);
        fruitsLayout = findViewById(R.id.fruitsLayout);
        meatsLayout = findViewById(R.id.meatsLayout);
        grainsLayout = findViewById(R.id.grainsLayout);
        spicesLayout = findViewById(R.id.spicesLayout);

        addCheckBoxes(essentialLayout, new String[]{"Яйца", "Растительное масло", "Картофель", "Лук", "Сахар", "Молоко", "Сливочное масло", "Мука", "Соль", "Перец"});
        addCheckBoxes(milkAndEggsLayout, new String[]{"Яйца", "Сливочное масло", "Молоко", "Сметана", "Творог", "Кефир", "Йогурт", "Маргарин", "Сгущенка", "Сыр"});
        addCheckBoxes(cheesesLayout, new String[]{"Твердый сыр", "Пармезан", "Моцарелла", "Сливочный сыр", "Плавленый сыр", "Гауда", "Чеддер", "Бри", "Голландский сыр"});
        addCheckBoxes(vegetablesLayout, new String[]{"Помидоры", "Огурцы", "Морковь", "Капуста", "Свекла", "Чеснок", "Болгарский перец", "Баклажаны", "Кабачки"});
        addCheckBoxes(fruitsLayout, new String[]{"Яблоки", "Бананы", "Апельсины", "Груши", "Киви", "Виноград", "Арбуз", "Клубника", "Черника"});
        addCheckBoxes(meatsLayout, new String[]{"Курица", "Говядина", "Свинина", "Баранина", "Индейка", "Кролик", "Колбаса", "Ветчина", "Сосиски"});
        addCheckBoxes(grainsLayout, new String[]{"Рис", "Гречка", "Овсянка", "Кукурузная крупа", "Перловка", "Булгур", "Пшено", "Макароны", "Хлеб"});
        addCheckBoxes(spicesLayout, new String[]{"Паприка", "Карри", "Корица", "Куркума", "Имбирь", "Гвоздика", "Базилик", "Орегано", "Тимьян"});

        Button findRecipeButton = findViewById(R.id.findRecipeButton);
        findRecipeButton.setOnClickListener(v -> {
            if (areIngredientsSelected()) {
                // Переход на экран с рецептом
                Intent intent = new Intent(FindRecipeActivity.this, RecipeListActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(FindRecipeActivity.this, "Выберите ингредиенты", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addCheckBoxes(LinearLayout layout, String[] items) {
        for (String item : items) {
            CheckBox checkBox = new CheckBox(this);
            checkBox.setText(item);
            layout.addView(checkBox);

            checkBoxMap.putIfAbsent(item, new ArrayList<>());
            checkBoxMap.get(item).add(checkBox);

            checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> syncCheckBoxes(item, isChecked));
        }
    }

    private void syncCheckBoxes(String item, boolean isChecked) {
        for (CheckBox checkBox : checkBoxMap.get(item)) {
            checkBox.setChecked(isChecked);
        }
    }

    private boolean areIngredientsSelected() {
        return isSectionSelected(essentialLayout) || isSectionSelected(milkAndEggsLayout) || isSectionSelected(cheesesLayout) || isSectionSelected(vegetablesLayout) || isSectionSelected(fruitsLayout) || isSectionSelected(meatsLayout) || isSectionSelected(grainsLayout) || isSectionSelected(spicesLayout);
    }

    private boolean isSectionSelected(LinearLayout layout) {
        int childCount = layout.getChildCount();
        for (int i = 0; i < childCount; i++) {
            CheckBox checkBox = (CheckBox) layout.getChildAt(i);
            if (checkBox.isChecked()) {
                return true;
            }
        }
        return false;
    }
}

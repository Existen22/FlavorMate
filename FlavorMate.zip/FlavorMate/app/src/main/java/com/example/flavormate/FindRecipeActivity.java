package com.example.flavormate;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class FindRecipeActivity extends AppCompatActivity {

    private LinearLayout essentialLayout, milkAndEggsLayout, cheesesLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_recipe);

        Button backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        essentialLayout = findViewById(R.id.essentialLayout);
        milkAndEggsLayout = findViewById(R.id.milkAndEggsLayout);
        cheesesLayout = findViewById(R.id.cheesesLayout);

        addCheckBoxes(essentialLayout, new String[]{"Яйца", "Растительное масло", "Картофель", "Лук", "Сахар", "Молоко", "Сливочное масло", "Мука"});

        addCheckBoxes(milkAndEggsLayout, new String[]{"Яйца", "Сливочное масло", "Молоко", "Сметана", "Творог", "Кефир", "Йогурт", "Маргарин", "Сгущенка"});

        addCheckBoxes(cheesesLayout, new String[]{"Твердый сыр", "Пармезан", "Моцарелла", "Сливочный сыр", "Плавленый сыр"});
    }

    private void addCheckBoxes(LinearLayout layout, String[] items) {
        for (String item : items) {
            CheckBox checkBox = new CheckBox(this);
            checkBox.setText(item);
            layout.addView(checkBox);
        }
    }
}

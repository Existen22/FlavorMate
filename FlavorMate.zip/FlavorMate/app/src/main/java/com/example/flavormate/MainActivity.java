package com.example.flavormate;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.lang.reflect.Field;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Находим BottomNavigationView
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        // Загружаем фрагмент по умолчанию (например, HomeFragment)
        if (bottomNavigationView != null) {
            loadFragment(new HomeFragment());

            bottomNavigationView.setOnItemSelectedListener(item -> {
                // Используем рефлексию для получения идентификаторов
                int itemId = item.getItemId();
                if (isResourceIdAvailable("nav_home", itemId)) {
                    loadFragment(new HomeFragment());
                    return true;
                } else if (isResourceIdAvailable("nav_search", itemId)) {
                    loadFragment(new SearchFragment());
                    return true;
                } else if (isResourceIdAvailable("nav_add_recipe", itemId)) {
                    loadFragment(new AddRecipeFragment());
                    return true;
                } else if (isResourceIdAvailable("nav_video", itemId)) { // Меняем местами с Profile
                    loadFragment(new VideoFragment());
                    return true;
                } else if (isResourceIdAvailable("nav_profile", itemId)) { // Меняем местами с Video
                    loadFragment(new ProfileFragment());
                    return true;
                }
                return false;
            });
        }
    }

    // Проверяем, доступен ли ресурс по имени
    private boolean isResourceIdAvailable(String resourceName, int itemId) {
        try {
            Field field = R.id.class.getField(resourceName);
            return field.getInt(null) == itemId;
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Метод для загрузки фрагментов
    private void loadFragment(Fragment fragment) {
        if (fragment != null) {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.fragment_container, fragment);
            transaction.addToBackStack(null);  // Сохраняем стек фрагментов
            transaction.commit();
        }
    }
}

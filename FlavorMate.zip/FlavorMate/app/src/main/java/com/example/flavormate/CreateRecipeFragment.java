package com.example.flavormate;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.VideoView;
import androidx.fragment.app.Fragment;

public class CreateRecipeFragment extends Fragment {

    private static final int PICK_IMAGE = 1;
    private static final int PICK_VIDEO = 2;

    private EditText recipeName, recipeDescription, cookingTime, cookingInstructions;
    private ImageView recipeImage;
    private VideoView recipeVideo;
    private Button btnSaveRecipe;

    public CreateRecipeFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_create_recipe, container, false);

        // Инициализация переменных
        recipeName = view.findViewById(R.id.recipeName);
        recipeDescription = view.findViewById(R.id.recipeDescription);
        cookingTime = view.findViewById(R.id.cookingTime);
        cookingInstructions = view.findViewById(R.id.cookingInstructions);
        recipeImage = view.findViewById(R.id.recipeImage);
        recipeVideo = view.findViewById(R.id.recipeVideo);
        btnSaveRecipe = view.findViewById(R.id.btnSaveRecipe);

        // Установка слушателя на кнопку "Сохранить рецепт"
        btnSaveRecipe.setOnClickListener(v -> saveRecipe());

        // Слушатель для выбора изображения
        recipeImage.setOnClickListener(v -> openImagePicker());

        // Слушатель для выбора видео
        recipeVideo.setOnClickListener(v -> openVideoPicker());

        return view;
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE);
    }

    private void openVideoPicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_VIDEO);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == getActivity().RESULT_OK && data != null) {
            Uri selectedUri = data.getData();
            if (requestCode == PICK_IMAGE) {
                recipeImage.setImageURI(selectedUri);
            } else if (requestCode == PICK_VIDEO) {
                recipeVideo.setVideoURI(selectedUri);
                recipeVideo.start();
            }
        }
    }

    private void saveRecipe() {
        String title = recipeName.getText().toString().trim();
        String description = recipeDescription.getText().toString().trim();
        String time = cookingTime.getText().toString().trim();
        String instructions = cookingInstructions.getText().toString().trim();

        if (title.isEmpty() || description.isEmpty() || time.isEmpty() || instructions.isEmpty()) {
            Toast.makeText(getContext(), "Пожалуйста, заполните все поля", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getContext(), "Рецепт успешно сохранен!", Toast.LENGTH_SHORT).show();
        }
    }
}

package com.example.flavormate;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Проверка, является ли пользователь гостем
        boolean isGuest = getIntent().getBooleanExtra("isGuest", false);

        TextView profileText = findViewById(R.id.profile_text);
        if (isGuest) {
            profileText.setText("Вы вошли как гость. Приветствуем!");
        } else {
            profileText.setText("Добро пожаловать в ваш профиль!");
        }

        // Кнопка "Назад"
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Закрывает активность и возвращает на предыдущий экран
            }
        });
    }
}

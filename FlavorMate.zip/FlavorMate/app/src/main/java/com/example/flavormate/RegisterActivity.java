package com.example.flavormate;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        findViewById(R.id.back_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Button registerButton = findViewById(R.id.register_button);
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText emailField = findViewById(R.id.email_field);
                EditText passwordField = findViewById(R.id.password_field);
                EditText confirmPasswordField = findViewById(R.id.confirm_password_field);

                String email = emailField.getText().toString();
                String password = passwordField.getText().toString();
                String confirmPassword = confirmPasswordField.getText().toString();

                if (email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                    TextView errorMessage = findViewById(R.id.error_message);
                    errorMessage.setText("Пожалуйста, заполните все поля");
                }
                else if (!password.equals(confirmPassword)) {
                    TextView errorMessage = findViewById(R.id.error_message);
                    errorMessage.setText("Пароли не совпадают");
                }
                else if (!isPasswordValid(password)) {
                    TextView errorMessage = findViewById(R.id.error_message);
                    errorMessage.setText("Пароль должен содержать минимум 6 символов, " +
                            "одну цифру и одну заглавную букву");
                }
                else {
                    Toast.makeText(getApplicationContext(), "Регистрация успешна! Теперь логиньтесь.", Toast.LENGTH_LONG).show();

                    Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                    startActivity(intent);

                    finish();
                }
            }
        });
    }

    private boolean isPasswordValid(String password) {
        if (password.length() < 6) {
            return false;
        }
        if (!password.matches(".*\\d.*")) {
            return false;
        }
        if (!password.matches(".*[A-Z].*")) {
            return false;
        }
        return true;
    }
}
